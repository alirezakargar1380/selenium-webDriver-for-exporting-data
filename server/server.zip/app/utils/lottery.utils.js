function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}