const app = require("./app");
app.listen(3001, () => {
    console.log("you can see your code here: http://localhost:3001/api/result")
})

// const combinations = require('combinations');
// var myArray = [ '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' ];
//
// combinations(myArray, 11,11)
// console.log(combinations(myArray, 11,11))


// const combinate = require('combinate');
// import combinate from "combinate";
//
//
// const values = {
//   color: ["red", "blue", "green"],
//   mode: ["light", "dark"],
// };
//
// const combinations = combinate(values);
//
// console.log(combinations);


